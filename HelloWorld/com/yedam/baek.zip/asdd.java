package baek;

import java.util.Scanner;

public class asdd {
	public static void main(String[] args) {
		int M;
		Scanner scn = new Scanner(System.in);
		M = scn.nextInt();
		int x = 0;
		x = scn.nextInt();
		int[] intArr = new int[20];
		
	}
	public void add(int[] intArr, int x) {
		boolean chk = false;
		for(int i=0;i<20;i++) {
			if(intArr[i]==x) {
				chk = true;
				break;
			}
		}
		if(chk == false) {
			for(int i=0;i<20;i++) {
				if(intArr[i]==0) {
					intArr[i]=x;
				}
			}
		}
	}
	
	public void remove(int[] intArr, int x){
		for(int i=0;i<20;i++) {
			if(intArr[i]==x) {
				intArr[i]=0;
				break;
			}
		}
	}
	
	public void check(int[] intArr, int x) {
		boolean chk = false;
		for(int i=0;i<20;i++) {
			if(intArr[i]==x) {
				System.out.println("1");
				chk = true;
			}
			else if(i<=20){
				System.out.println("0");
				break;
			}
		}
	}
	
	public void toggle(int[] intArr, int x) {
		for(int i=0;i<20;i++) {
			if(intArr[i]==x) {
				remove(intArr, x);
				break;
			}
			else if(i<=20) {
				add(intArr, x);
			}
		}
	}
	
	public void all(int[] intArr, int x) {
		int j=1;
		for(int i=0;i<20;i++) {
			intArr[i]=j++;
		}
	}
	
	public void empty(int[] intArr, int x) {
		for(int i=0;i<20;i++) {
			intArr[i]=0;
		}
	}
}
