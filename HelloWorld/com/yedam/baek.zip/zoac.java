//package baek;
//
//import java.util.Scanner;
//
//public class zoac {
//	public static void main(String[] args) {
//		int i,j,k,l;
//		
//		Scanner scn = new Scanner(System.in);
//		i = scn.nextInt();
//		j = scn.nextInt();
//		k = scn.nextInt();
//		l = scn.nextInt();
//		double tmp1 = k+1;
//		double tmp2 = l+1;
//		int tmp3 = (int)Math.ceil(i/tmp1);
//		int tmp4 = (int)Math.ceil(j/tmp2);
//		System.out.println(tmp3*tmp4);
//		scn.close();
//	}
//}
