package baek;

public class test {
	public static void main(String[] args) {
		int i = 7;
		int j = 3;
		System.out.println(i/j);
	}
}
