//package baek;
//
//import java.util.Scanner;
//
//public class bee {
//	public static void main(String[] args) {
//		long N=0;
//		Scanner scn = new Scanner(System.in);
//		N = scn.nextInt();
//		int i=1;
//		int j=2;
//		while(true) {
//			if(N==1) {
//				System.out.println("1");
//				break;
//			}
//			if(j>N) {
//				System.out.println(i);
//				break;
//			}
//			j = j+(6*i);
//			i++;
//		}
//	}
//}